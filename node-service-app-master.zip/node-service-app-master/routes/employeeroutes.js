var express = require("express");
const { where } = require("sequelize/dist");
var route = express.Router();
const db=require('../orm/db.config')
const sequelize = require('../orm/connection');
var model = require('../orm/model')
const {
   Sequelize,
   Model,
   DataTypes,
   QueryTypes
} = require('sequelize');
route.post("/employees", async function (request, response) {
    const { username } = request.body
    try {
    const result = await model.employee.findAll({ where: { wfm_manager: username, lockstatus: "not_requested" } })   
    response.json(result)
   }
   catch (e) {
      console.log(e)
      response.status(500)
   }
})

route.post("/employeeswithskill", async function (request, response) {
   const { username } = request.body
   try {
      await sequelize.query('select e.employee_id as EmployeeID,e.name as Name,group_concat(s.name) as Skills,e.lockstatus as Status,e.experience as Experience, e.manager as Manager,p.name as Profile from employee e join skillmap sk on e.employee_id=sk.employee_id join skills s on sk.skillid=s.skillid join profile p on p.profile_id = e.profile_id where e.manager like :managername and e.lockstatus="not_requested" group by e.employee_id;', {
          replacements: {
              managername: username
          },
          model: model.employee,
          mapToModel: true,
          type: sequelize.QueryTypes.SELECT
      }).then(function(employees) {
          response.status(200).json(employees)
      })
  } catch (e) {
      console.log(e);
      response.status(500);
  }
})

// route.post("/employeeswithskill", async function (request, response) {
//    const { username } = request.body
//    try { 

//          var result = await model.employee.findAll({
//             where: { wfm_manager: username},
//             include: [
//               {
//                  model: model.skillmap,
//                  as: 'skillmaps',
//                  include: [
//                   {
//                      model: model.skills,
//                      as: 'skills',
//                   }
//                 ]  
//               }
//             ]
//           });
        
//          response.json(result)
//   }
//   catch (e) {
//      console.log(e)
//      response.status(500)
//   }
// })

route.post("/skills", async function (request, response) {
   const { empId } = request.body
   try {
    var s =  model.skillmap.hasMany(model.skillmap, {foreignKey: 'skillid'})
model.employee.belongsTo(model.employee, {foreignKey: 'employee_id'})

const result = await model.employee.findAll({ where: { employee_id: empId}, include: [model.skillmap]})
   // const result = await model.skills.findAll({ where: { employee_id: empId } })   
   response.json(result)
  }
  catch (e) {
     console.log(e)
     response.status(500)
  }
})

route.post("/updatesoftlock", async function (request, response) {
   const { lockID, empID, reqMsg } = request.body
   try {
      const result = await model.softlock.update(
        { requestmessage: reqMsg,
          status: request.body.status,
          lastupdated: Date.now(),
          mgrlastupdate: Date.now(),
        },
        { where: { lockid: lockID } }
      )
      response.send("Request lock message updated")

    } catch (err) {
      response.status(500)
   }
})

route.post("/addsoftlock", async function (request, response) {
   try{
      const { manager, empId, reqMsg } = request.body
      const result = await model.softlock.create({
         employee_id: empId,
         manager: manager,
         reqdate: Date.now(),
         lastupdated: Date.now(),
         requestmessage: reqMsg,
         status: 'waiting'
     })
     .then(function (data) {
        console.log("success")
         if (data) {
             response.send("Data inserted");
         } else {
             response.status(400).send('Error in insert new record');
         }
     });
   }
   catch(err){
      response.status(500)
   }  
})


module.exports = route